import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
  navBar: {
    backgroundColor: '#2e99e4'
  },
  barButtonTextStyle: {
    fontSize: 18
  }
});
