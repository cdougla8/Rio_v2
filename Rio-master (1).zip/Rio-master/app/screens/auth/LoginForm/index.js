import LoginFormComponent from './loginForm';

export default LoginFormComponent;
