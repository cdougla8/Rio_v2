import SignupFormComponent from './signupForm';

export default SignupFormComponent;
