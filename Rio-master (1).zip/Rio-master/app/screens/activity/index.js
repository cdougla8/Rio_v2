import Activity from './activity';

export default Activity;
