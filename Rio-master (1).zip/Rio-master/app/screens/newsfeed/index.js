import Newsfeed from './newsfeed';

export default Newsfeed;

