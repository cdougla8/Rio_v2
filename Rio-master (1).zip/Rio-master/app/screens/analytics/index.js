import Analytics from './analytics';

export default Analytics;

