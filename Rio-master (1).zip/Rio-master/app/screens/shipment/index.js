import Shipment from './shipment';

export default Shipment;

