import routerReducer from './routesReducer';

describe('RoutesReducer', () => {
  describe('Routes', () => {
    it('Should be provide the initial state', () => {
      expect(2).toBe(2);
    });
  });
});
