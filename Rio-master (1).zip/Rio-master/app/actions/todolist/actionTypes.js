export const ADD = 'ADD';
export const REMOVE = 'REMOVE';
